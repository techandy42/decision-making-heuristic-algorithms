import random

# board by its index
board = [0, 0, 0, 0, 0, 0, 0, 0, 0]
#player: -1 / bot: 1
def show_board():
    for index in range(len(board)):
        print("|", end="")
        if board[index] == 0:
            print(" ", end="")
        elif board[index] == -1:
            print("O", end="")
        else:
            print("X", end="")
        if index % 3 == 2:
            print("|")

def main():
    turn = flip_coin()
    if turn:
        print("PLayer goes first (player: O / bot: X)")
    else:
        print("Bot goes first (player: O / bot: X)")
    #if turn = True -> player, else bot
    while True:
        #player
        if turn:
            show_board()
            while True:
                try:
                    position = int(input())
                    if position >= 0 and position < 9:
                        if board[position] == 0:
                            board[position] = -1
                            break
                        else:
                            print("Input a number for an empty space")
                            show_board()
                    else:
                        print("Input a number between 0 and 8 (inclusive)")
                        show_board()
                except:
                    print("Input a valid number between 0 and 8 (inclusive)")
                    show_board()
            turn = False
        #bot
        else:
            show_board()
            while True:
                try:
                    position = int(input())
                    if position >= 0 and position < 9:
                        if board[position] == 0:
                            board[position] = -1
                            break
                        else:
                            print("Input a number for an empty space")
                            show_board()
                    else:
                        print("Input a number between 0 and 8 (inclusive)")
                        show_board()
                except:
                    print("Input a valid number between 0 and 8 (inclusive)")
                    show_board()
            board[position] = 1
            turn = True
        #2: tie / 0: in_progress / -1: player victory / 1: bot victory
        result = determine_board()
        if result == -1:
            show_board()
            print("Player has won")
            break
        elif result == 1:
            show_board()
            print("Bot has won")
            break
        elif result == 2:
            show_board()
            print("Tie")
            break

def determine_board():
    player_victory = False
    bot_victory = False
    for i in range(3):
        if board[i * 3] == board[i * 3 + 1] == board[i * 3 + 2] == -1:
            player_victory = True
        if board[i * 3] == board[i * 3 + 1] == board[i * 3 + 2] == 1:
            bot_victory = True
        if board[i] == board[i + 3] == board[i + 6] == -1:
            player_victory = True
        if board[i] == board[i + 3] == board[i + 6] == 1:
            bot_victory = True
    if board[0] == board[4] == board[8] == -1:
        player_victory = True
    if board[0] == board[4] == board[8] == 1:
        bot_victory = True
    if board[2] == board[4] == board[6] == -1:
        player_victory = True
    if board[2] == board[4] == board[6] == 1:
        bot_victory = True
    tie = True
    for i in range(9):
        if board[i] == 0:
            tie = False
    if player_victory:
        return -1
    elif bot_victory:
        return 1
    elif tie:
        return 2
    return 0

def flip_coin():
    return bool(random.getrandbits(1))

if __name__ == "__main__":
    main()